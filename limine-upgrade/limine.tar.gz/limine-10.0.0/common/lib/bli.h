#ifndef LIB__BLI_H__
#define LIB__BLI_H__

#if defined (UEFI)

void init_bli(void);
void bli_on_boot(void);

#endif

#endif
